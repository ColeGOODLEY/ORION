// =====================================
// ORION CONTEXT ENGINE
// Adaptive Context Build 4.0
// Natural Conversation Integration
// =====================================


const ORION_CONTEXT = {

    history: [],

    maxHistory: 20,

    maxMessageLength: 800,


    // =====================================
    // SANITIZE MESSAGE
    // =====================================

    sanitizeMessage(message){

        if(!message){
            return "";
        }

        message = String(message).trim();

        if(message.length <= this.maxMessageLength){
            return message;
        }

        return message.substring(0, this.maxMessageLength) + "...";
    },


    // =====================================
    // ADD MESSAGE
    // =====================================

    addMessage(role, message){

        const cleanMessage = this.sanitizeMessage(message);

        if(!cleanMessage){
            return;
        }

        this.history.push({
            role: role,
            message: cleanMessage,
            timestamp: new Date().toISOString()
        });

        while(this.history.length > this.maxHistory){
            this.history.shift();
        }

        this.save();
    },


    // =====================================
    // SAVE CONTEXT
    // =====================================

    save(){

        localStorage.setItem(
            "orion_context",
            JSON.stringify(this.history)
        );
    },


    // =====================================
    // LOAD CONTEXT
    // =====================================

    load(){

        try{

            this.history = JSON.parse(
                localStorage.getItem("orion_context")
            ) || [];

        }
        catch(error){

            console.warn(
                "ORION Context: Invalid stored context. Resetting."
            );

            this.history = [];
        }

        if(!Array.isArray(this.history)){
            this.history = [];
        }

        this.history = this.history
            .filter(item => item && item.role && item.message)
            .map(item => ({
                role: item.role,
                message: this.sanitizeMessage(item.message),
                timestamp: item.timestamp || new Date().toISOString()
            }))
            .slice(-this.maxHistory);

        return this.history;
    },


    // =====================================
    // GET RECENT CONTEXT
    // =====================================

    getRecent(limit = this.maxHistory){

        return this.history
            .slice(-Math.max(1, limit))
            .map(item => ({
                role: item.role,
                message: item.message
            }));
    },


    // =====================================
    // GET RELEVANT CONTEXT
    // =====================================

    getRelevant(command){

        // For short/follow-up messages, recent context is more useful
        // than keyword matching because the command may contain almost
        // no information by itself.
        if(
            typeof ORION_CONVERSATION !== "undefined" &&
            ORION_CONVERSATION.isFollowUp(command)
        ){
            return this.getRecent();
        }

        if(!command){
            return this.getRecent();
        }

        const keywords =
            typeof ORION_CONVERSATION !== "undefined"
            ? ORION_CONVERSATION.extractKeywords(command)
            : command.toLowerCase().split(/\s+/).filter(word => word.length > 2);

        if(keywords.length === 0){
            return this.getRecent();
        }

        const relevant = this.history.filter(item => {

            const text = item.message.toLowerCase();

            return keywords.some(word => text.includes(word));
        });

        if(relevant.length === 0){
            return this.getRecent();
        }

        return relevant
            .slice(-this.maxHistory)
            .map(item => ({
                role: item.role,
                message: item.message
            }));
    },


    // =====================================
    // CONVERSATION SUMMARY
    // =====================================

    getSummary(){

        if(this.history.length === 0){
            return "";
        }

        return this.history
            .slice(-6)
            .map(item =>
                `${item.role === "user" ? "User" : "ORION"}: ${item.message}`
            )
            .join("\n");
    },


    // =====================================
    // NATURAL CONVERSATION STATE
    // =====================================

    getConversationState(command){

        if(
            typeof ORION_CONVERSATION !== "undefined" &&
            typeof ORION_CONVERSATION.getState === "function"
        ){
            return ORION_CONVERSATION.getState(command);
        }

        return {
            turnCount: this.history.filter(item => item.role === "user").length,
            hasHistory: this.history.length > 0,
            isFollowUp: false,
            previousUser: "",
            previousAssistant: "",
            topicTerms: []
        };
    },


    // =====================================
    // FULL CONVERSATION PAYLOAD
    // =====================================

    getConversationPayload(command){

        if(
            typeof ORION_CONVERSATION !== "undefined" &&
            typeof ORION_CONVERSATION.getPromptContext === "function"
        ){
            return ORION_CONVERSATION.getPromptContext(command);
        }

        return {
            history: this.getRecent(),
            state: this.getConversationState(command),
            instruction:
                "Use the recent conversation as continuous context."
        };
    },


    // =====================================
    // CLEAR CONTEXT
    // =====================================

    clear(){

        this.history = [];

        localStorage.removeItem("orion_context");
    }
};


// =====================================
// CONTEXT BUILDER
// =====================================

function getContext(command){

    const conversationPayload =
        ORION_CONTEXT.getConversationPayload(command);

    return {

        user: "Mr. Goodley",

        assistant: "ORION",

        objective:
            "Provide strategic assistance and guidance while maintaining continuous, natural conversation.",

        currentCommand: command,

        conversationSummary:
            ORION_CONTEXT.getSummary(),

        conversationHistory:
            ORION_CONTEXT.getRelevant(command),

        conversation:
            conversationPayload.history,

        conversationState:
            conversationPayload.state,

        conversationInstruction:
            conversationPayload.instruction
    };
}


// =====================================
// INITIALIZE CONTEXT
// =====================================

ORION_CONTEXT.load();
