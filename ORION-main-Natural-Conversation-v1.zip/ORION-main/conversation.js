// =====================================
// ORION CONVERSATION ENGINE
// Build 2.0
// Natural Conversation Foundation
// =====================================


// =====================================
// LEGACY FALLBACK STORAGE
// =====================================

let conversationHistory =
JSON.parse(
    localStorage.getItem("orion_conversation")
) || [];


const ORION_CONVERSATION = {

    maxHistory: 20,

    maxMessageLength: 800,

    stopWords: new Set([
        "the","a","an","and","or","but","if","then","than",
        "is","are","was","were","be","been","being","to","of",
        "in","on","at","for","from","with","about","as","by",
        "it","this","that","these","those","i","me","my","we",
        "you","your","he","she","they","them","do","does","did",
        "can","could","would","should","will","what","when","where",
        "why","how","which","who","all","just","really","very"
    ]),

    followUpPatterns: [
        /^what about\b/i,
        /^how about\b/i,
        /^what if\b/i,
        /^which one\b/i,
        /^which is\b/i,
        /^what do you mean\b/i,
        /^why\b/i,
        /^how\b/i,
        /^and\b/i,
        /^then\b/i,
        /^so\b/i,
        /^okay,? what\b/i,
        /^what next\b/i,
        /^now what\b/i,
        /^tell me more\b/i,
        /^go on\b/i,
        /^explain that\b/i
    ],

    pronouns: new Set([
        "it","that","this","they","them","he","she","those",
        "these","one","ones","there","then","same"
    ]),


    // =====================================
    // SANITIZE MESSAGE
    // =====================================

    sanitizeMessage(message){

        if(!message){
            return "";
        }

        const text = String(message).trim();

        if(text.length <= this.maxMessageLength){
            return text;
        }

        return text.substring(0, this.maxMessageLength) + "...";
    },


    // =====================================
    // NORMALIZE HISTORY
    // =====================================

    normalizeHistory(history){

        if(!Array.isArray(history)){
            return [];
        }

        return history
            .filter(item => item && item.role && item.message)
            .map(item => ({
                role: item.role === "assistant" ? "assistant" : "user",
                message: this.sanitizeMessage(item.message),
                timestamp: item.timestamp || new Date().toISOString()
            }))
            .slice(-this.maxHistory);
    },


    // =====================================
    // GET HISTORY SOURCE
    // =====================================

    getHistory(){

        if(
            typeof ORION_CONTEXT !== "undefined" &&
            Array.isArray(ORION_CONTEXT.history)
        ){
            return ORION_CONTEXT.history;
        }

        return conversationHistory;
    },


    // =====================================
    // STORE MESSAGE
    // =====================================

    addMessage(role, message){

        const cleanMessage = this.sanitizeMessage(message);

        if(!cleanMessage){
            return;
        }

        // ORION_CONTEXT is the authoritative conversation store.
        if(
            typeof ORION_CONTEXT !== "undefined" &&
            typeof ORION_CONTEXT.addMessage === "function"
        ){
            ORION_CONTEXT.addMessage(role, cleanMessage);
            return;
        }

        conversationHistory.push({
            role: role,
            message: cleanMessage,
            timestamp: new Date().toISOString()
        });

        conversationHistory = conversationHistory.slice(-this.maxHistory);

        localStorage.setItem(
            "orion_conversation",
            JSON.stringify(conversationHistory)
        );
    },


    // =====================================
    // RECENT HISTORY
    // =====================================

    getRecent(limit = this.maxHistory){

        return this.normalizeHistory(this.getHistory())
            .slice(-Math.max(1, limit))
            .map(item => ({
                role: item.role,
                message: item.message
            }));
    },


    // =====================================
    // KEYWORD EXTRACTION
    // =====================================

    extractKeywords(text){

        if(!text){
            return [];
        }

        return [...new Set(
            String(text)
                .toLowerCase()
                .replace(/[^a-z0-9'\s-]/g, " ")
                .split(/\s+/)
                .map(word => word.replace(/^['-]+|['-]+$/g, ""))
                .filter(word =>
                    word.length > 2 &&
                    !this.stopWords.has(word) &&
                    !/^\d+$/.test(word)
                )
        )];
    },


    // =====================================
    // POSSIBLE TOPIC TERMS
    // =====================================

    extractTopic(command){

        const recentUsers = this.normalizeHistory(this.getHistory())
            .filter(item => item.role === "user")
            .slice(-4)
            .map(item => item.message);

        const combined = [
            ...recentUsers,
            command || ""
        ].join(" ");

        const keywords = this.extractKeywords(combined);

        return keywords.slice(-6);
    },


    // =====================================
    // FOLLOW-UP DETECTION
    // =====================================

    isFollowUp(command){

        if(!command){
            return false;
        }

        const text = String(command).trim().toLowerCase();
        const words = text.split(/\s+/).filter(Boolean);

        if(this.followUpPatterns.some(pattern => pattern.test(text))){
            return true;
        }

        if(words.length <= 7){
            const hasPronoun = words.some(word =>
                this.pronouns.has(word.replace(/[?.,!]/g, ""))
            );

            if(hasPronoun){
                return true;
            }
        }

        return false;
    },


    // =====================================
    // CONVERSATION STATE
    // =====================================

    getState(command){

        const history = this.normalizeHistory(this.getHistory());
        const users = history.filter(item => item.role === "user");
        const assistants = history.filter(item => item.role === "assistant");

        const latestUser = users.length > 0
            ? users[users.length - 1].message
            : "";

        // The current command is already captured before the brain runs.
        // Prefer the user turn immediately before it when available.
        const currentIsLatest =
            command &&
            latestUser.trim().toLowerCase() === String(command).trim().toLowerCase();

        const previousUserIndex =
            currentIsLatest ? users.length - 2 : users.length - 1;

        const previousUser = previousUserIndex >= 0
            ? users[previousUserIndex].message
            : "";

        const previousAssistant = assistants.length > 0
            ? assistants[assistants.length - 1].message
            : "";

        return {
            turnCount: users.length,
            hasHistory: history.length > 0,
            isFollowUp: this.isFollowUp(command),
            previousUser: previousUser,
            previousAssistant: previousAssistant,
            topicTerms: this.extractTopic(command)
        };
    },


    // =====================================
    // AI CONVERSATION CONTEXT
    // =====================================

    getPromptContext(command){

        const state = this.getState(command);

        return {
            history: this.getRecent(this.maxHistory),
            state: state,
            instruction:
                "Treat the conversation as continuous. Use previous turns to resolve references, follow-up questions, pronouns, and omitted subjects. Do not ask the user to repeat information that is already available in the conversation context. If the user's message is a follow-up, answer it using the active topic. If context is genuinely ambiguous, ask a concise clarification question."
        };
    },


    // =====================================
    // CLEAR
    // =====================================

    clear(){

        conversationHistory = [];

        localStorage.removeItem("orion_conversation");

        if(
            typeof ORION_CONTEXT !== "undefined" &&
            typeof ORION_CONTEXT.clear === "function"
        ){
            ORION_CONTEXT.clear();
        }
    },


    // =====================================
    // COUNT
    // =====================================

    count(){
        return this.normalizeHistory(this.getHistory()).length;
    }
};


// =====================================
// COMPATIBILITY FUNCTIONS
// =====================================

function saveConversation(role, message){
    ORION_CONVERSATION.addMessage(role, message);
}


function getConversationContext(command){
    return ORION_CONVERSATION.getRecent(
        ORION_CONVERSATION.maxHistory
    );
}


function getConversationState(command){
    return ORION_CONVERSATION.getState(command);
}


function getConversationPromptContext(command){
    return ORION_CONVERSATION.getPromptContext(command);
}


function clearConversation(){
    ORION_CONVERSATION.clear();
}


function conversationCount(){
    return ORION_CONVERSATION.count();
}
